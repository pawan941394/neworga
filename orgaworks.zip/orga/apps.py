from django.apps import AppConfig


class OrgaConfig(AppConfig):
    name = 'orga'
